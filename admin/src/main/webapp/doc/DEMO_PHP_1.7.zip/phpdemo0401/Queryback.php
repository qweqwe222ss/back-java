﻿<?php
header("Content-Type:text/html;charset=utf-8");
//您的商户号。需要修改成您分配的商户号
$app_id='*****************';
//您的商户KEY。需要修改成您分配的商户KEY
$key='*********************';
//订单流水号，需要您输入
 $transaction_no=$_POST['transaction_no'];
query($transaction_no,$app_id,$key);

function query($transaction_no,$app_id,$key){
	//跳转地址
	$api_url = "http://api.vpayxx.com/v1/query.action";
	//加密用的数组
	$params = array(
		'app_id' => $app_id, //商户号
		'transaction_no' => $transaction_no  //商品流水号
	);
	
	//将各值放入$post里准备提交
	$post["app_id"] = $app_id;
	$sign=ms_sign($params,$key);
	$post["sign"] = $sign;
	$post["transaction_no"] = $transaction_no;
	//pr('提交参数:');
	pr($post);
	//提交查询 $api_rul是跳转地址，$post是提交的数据
	$return = curlPost($api_url, $post);
	//json解析返回值
	$return = json_decode($return, true);
	pr('返回参数:');
	pr($return);
	
	
	//将查询到的数据打印出来
	echo "<hr/>查询结果";
	
	$app_id =$return['data']['app_id'];
	echo "<br/>app_id：".$app_id;
	$order_no  =$return['data']['order_no'];
	echo "<br/>order_no ：".$order_no ;
	$amount  =$return['data']['amount'];
	echo "<br/>amount ：".$amount ;
	$succeeded  =$return['data']['succeeded'];
	echo "<br/>succeeded ：".$succeeded ;
	$transaction_no =$return['data']['transaction_no'];
	echo "<br/>transaction_no：".$transaction_no;
	if($succeeded == 1){
		echo "<br/>支付成功";
	}else if($succeeded == 2){
		echo "支付失败";
		$metadata  =$return['data']['metadata'];
	echo "<br/>metadata ：".$metadata ;
	$failure_code  =$return['data']['failure_code'];
	echo "<br/>failure_code ：".$failure_code ;
	$failure_msg  =$return['data']['failure_msg'];
	echo "<br/>failure_msg  ：".$failure_msg  ;
	
	
	}else{
		echo "支付处理中";
	}
	
}

function pr($arr){
	echo '<pre>';
	print_r($arr);
}

//跳转方法
function curlPost($api_url, $data = ''){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $api_url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSLVERSION, 1);//这个值不设置有时会出现error 35情况
	return curl_exec($ch);
}

//@param $key  收银台签名key
function ms_sign($params,$key){
	//将数组进行ascii码从小到大排序
	ksort($params);
	$temp_1="";
	//将数组的值全部赋予字符串
	foreach ($params as $k => $v) {
			$temp_1 = "".$temp_1."". $k."=".$v."&";
	}
	//再将key值加到字符串最后面
	$temp_2=$temp_1."key=".$key;
	var_dump($temp_2);
	//进行md5加密
	$sign=md5($temp_2);
	//将加密结果返回
		return $sign;
}


