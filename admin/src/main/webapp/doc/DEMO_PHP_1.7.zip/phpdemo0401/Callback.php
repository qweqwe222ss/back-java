<?php
header("Content-Type:text/html;charset=utf-8");
callback();
function callback(){
	//从回调的页面中获取数据	
	$sign = $_GET['sign']; // MD5签名。
	//以下的数据用来加密 加密后与获得的sign对比
	$app_id = $_GET['app_id'];   //商户号。
	$order_no  = $_GET['order_no'];	//商户订单号。 
	$amount = $_GET['amount'];	//订单总金额
	$metadata = $_GET['metadata'];	//元数据。
	$transaction_no = $_GET['transaction_no'];	//VPAY++平台交易流水号。
	$succeeded = $_GET['succeeded'];		//是否已充值成功。0处理中或状态未知,1 成功 ,2 失败
	$failure_code = $_GET['failure_code'];	//错误代码
	$failure_msg = $_GET['failure_msg'];	//错误信息描述。
	//将数据放入数组用于加密前的重新按照ascii从小到大排序
	$params = array(
		'app_id' => $app_id,
		'amount' => $amount,
		'metadata' => $metadata,
		'transaction_no' => $transaction_no,
		'order_no' => $order_no,
		'succeeded' => $succeeded,
		'failure_code' => $failure_code,
		'failure_msg' => $failure_msg,
	);
	//MD5加密，加密值是您的商户KEY。需要修改成您分配的商户KEY
	$key = "*********************";
	//将传过来的数据进行加密
	$_sign = ms_sign($params,$key);
	//将传过来的sign值与传过来的数据加密后的_sign进行对比，若一致，则说明成功
	if($_sign != $_sign){
		echo "error";
	}else{
		//两者相同 验证成功
		echo "success";
	}
	
}


//@param $ms_key  收银台签名key
function ms_sign($params,$ms_key){
	//将数组进行ascii码从小到大排序
	ksort($params);
	$temp_1="";
	//将数组的值全部赋予字符串
	foreach ($params as $k => $v) {
			$temp_1 = "".$temp_1."". $k."=".$v."&";
	}
	//再将key值加到字符串最后面
	$temp_2=$temp_1."key=".$ms_key;
	//进行md5加密
	$sign=md5($temp_2);
	//将加密结果返回
		return $sign;
}
?>