﻿<?php
header("Content-Type:text/html;charset=utf-8");
//您的商户号。需要修改成您分配的商户号
$app_id='**********';//测试 商户号
//您的商户KEY。需要修改成您分配的商户KEY
$key='**************';//测试 key

//运行
$return=recharge($app_id,$key);

function recharge($app_id,$key){
	//发送地址
	$api_url = "http://api.vpayxx.com/v1/recharge.action";
	
	//支付使用的第三方支付渠道
	$channel=$_POST['channel'];		
	 //商户订单号
	$order_no=date('Ymdhis', time()).mt_rand(100000, 9999999);  
	 //发起支付请求客户端的 IP 地址 例如127.0.0.1
	$client_ip="*************";    
	//订单总金额（必须大于 0），单位为对应币种的最小货币单位，人民币为分
	$amount=$_POST['amount'];    
	//商品标题
	$subject="************";		
	//商品描述信息	
	$body="***************";			    
	//支付结果异步通知url  回调地址 例如 127.0.0.1
	$notify_url="***************";
	//支付操作完成后界面返回url。例如127.0.0.1
	$return_url="*******************";	
	//$metadata=""; 				//元数据。详细参考1.3元数据。支付结果通知和支付结果返回会原样返回数据。
	//$extra="";				    //特定渠道发起交易时需要的额外参数。
	
	//这个数组用来给加密用的
	$param= array(
		'app_id' => $app_id,
		'channel' => $channel,
		'order_no' => $order_no,
		'client_ip' => $client_ip,
		'amount' => $amount,
		'subject' =>  $subject,
		'body' => $body,
		'notify_url' => $notify_url,
		'return_url' => $return_url,
	);
	//用来发送Http请求时使用
	$post["order_no"] = $order_no;
	$post["amount"] = $amount;
	$post["subject"] = $subject;
	$post["channel"] = $channel;
	$post["sign"] = ms_sign($param,$key);
	$post["return_url"] = $return_url;
	$post["client_ip"] = $client_ip;
	$post["body"] = $body;
	$post["notify_url"] = $notify_url;
	$post["app_id"] = $app_id;
	
	
	
	//pr('显示参数:');
	//pr($post);
	//提交地址和数据进行跳转   api_url 跳转地址 
	$return = curlPost($api_url, $post);
	//将传回来的值进行json解析
	$jasonObject = json_decode($return, true);
	//输出数组查看返回数据是否正确
	//print_r($jasonObject);

	//判断返回的coede值是否是成功的200	
	$code = $jasonObject["code"];
	echo "code:".$code;
		if ($code == "200") {
			/*
			 * 支付成功，转下一步处理
			 */
			/**
			 * VPY++平台订单号
			 */
			$transaction_no = $jasonObject['data']["transaction_no"];
			/**
			 * 商户订单号
			 */
			$order_no = $jasonObject['data']["order_no"];
			echo "<br/>";
			/**
			 * url值类型
			 * 1、url=跳转地址
			 * 2、html=表单html
			 * 3、imgurl=扫码图片地址
			 * 4、imgbase64=扫码图片base6编码
			 * 
			 * 手机和PC支付需要支持url和html，根据上游支付渠道不同，会轮询返回不同的结果。
			 * 二维码支付，需支持imgurl和imgbase64
			 */
			$url_type = $jasonObject['data']["url_type"];
			echo "<br/>";
			echo "url_type：".$url_type;
			/**
			 * url值
			 * 如url_type=html,form表格id值=vpay_recharge_form。可以使用js对vpay_recharge_form表单进行submit提交。
			 */
			$url = $jasonObject['data']["url"];
			echo "<br/>";
			echo $url;
			header($url);
			if ("url" == $url_type) {
				echo "url";
				header("Location: $url"); 
			} else if ("html" == $url_type) {
				echo "html";
				header("Location: $url"); 
			} else if ("imgurl" == $url_type) {
				echo "imgurl";
				header("Location: $url"); 
			} else if ("imgbase64" == $url_type) {
				echo "imgbase64";
				header("Location: $url"); 
			}
		} else {
			/*
			 * 返回code非200，支付失败
			 */
			echo("错误代码[code]：" . $code);
			$msssage = $jasonObject["msssage"];
			echo("错误消息[msssage]：" . $msssage);
		}
}

function pr($arr){
	echo '<pre>';
	print_r($arr);
}
//跳转页面方法
function curlPost($api_url='', $data = ''){
	if(empty($api_url) || empty($data)){
		echo "失败的";
		return false;
	}else{
		echo "跳转成功";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
	curl_setopt($ch, CURLOPT_URL, $api_url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);//POST数据
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSLVERSION, 1);//这个值不设置有时会出现error 35情况
	return curl_exec($ch);
	}
}

//@param $key        加密并返回加密结果
function ms_sign($params,$key){
	//将数组进行ascii码从小到大排序
	ksort($params);
	$temp_1="";
	foreach ($params as $k => $v) {
		//经过查询排序结果得知client_ip是&notify_url的前一个所以不直接设置&
		if($k == 'client_ip'){
			$temp_1 = "".$temp_1."". $k."=".$v;
		}
		//由于&not是转义符 所以需要单独设置
		else if($k == 'notify_url'){
			//$temp_1 = "".$temp_1."". htmlspecialchars("&notify_url")."=".$v."&";
			$temp_1 = "".$temp_1."". "&"."notify_url=".$v."&";
		}else{
			$temp_1 = "".$temp_1."". $k."=".$v."&";
		}
	}
	//echo "temp1：".$temp_1;
	//在值得字符串后添加密钥key
	$temp_2=$temp_1."key=".$key;
	//echo "<br/><br/>php排序完temp_2：".$temp_2;
	//将字符串进行md5加密
	var_dump($temp_2);
	$temp_3=md5($temp_2);
	//echo "<br/><br/>temp_2加密：".$temp_3;
	$sign = $temp_3;
		return $sign;
}


