package util;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import util.MD5;


public class KeyValues {

	private List<KeyValue> keyValues = new LinkedList<KeyValue>();

	public List<KeyValue> items() {
		return keyValues;
	}

	public void add(KeyValue kv) {
		if (kv != null && !(kv.getVal() == null || kv.getVal().trim().length() == 0)) {
			keyValues.add(kv);
		}
	}

	public String sign(String key) {
		StringBuilder sb = new StringBuilder();
		Collections.sort(keyValues, new Comparator<KeyValue>() {
			@Override
			public int compare(KeyValue l, KeyValue r) {
				return l.compare(r);
			}
		});
		for (KeyValue kv : keyValues) {
			URLUtils.appendParam(sb, kv.getKey(), kv.getVal());
		}
		String s = sb.toString() + "&key=" + key;

		s = s.substring(1, s.length());
		return MD5.sign(s);
	}

	public Map<String, Object> getMap() {
		Map<String, Object> postParamMap = new HashMap<String, Object>();
		for (KeyValue kv : keyValues) {
			postParamMap.put(kv.getKey(), kv.getVal());
		}

		return postParamMap;
	}

}
