

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;

import util.HttpHelper;
import util.HttpMethodType;
import util.KeyValue;
import util.KeyValues;

/**
 * 支付主动查询。@see VPAY++_API.doc 2.3支付主动查询
 */
public class QueryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public QueryServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// do nothing
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		KeyValues keyValues = new KeyValues();
		/**
		 * 您的商户号。需要修改成您分配的商户号
		 */
		keyValues.add(new KeyValue("app_id", "*********************"));
		/**
		 * VPY++平台订单号
		 */
		keyValues.add(new KeyValue("transaction_no", "*********************"));
		/**
		 * MD5加密，加密值是您的商户KEY。需要修改成您分配的商户KEY
		 */
		String sign = keyValues.sign("*********************");

		Map<String, Object> param = keyValues.getMap();
		param.put("sign", sign);
		
		/**
		 * 支付主动查询API地址
		 */
		String api_url = "http://api.vpayxx.com/v1/query.action";
		
		/**
		 * 调用VPY++查询接口，接口返回json格式的字符串
		 */
		String jsonResult = HttpHelper.getJSONFromHttp(api_url, param, HttpMethodType.POST);
		
		
		JSONObject jasonObject = JSONObject.parseObject(jsonResult);
		/**
		 * 您的商户号。
		 */
		String app_id = jasonObject.getString("app_id");
		/**
		 * 商户订单号
		 */
		String order_no = jasonObject.getString("order_no");
		/**
		 * 充值金额，单位是分。
		 */
		String amount = jasonObject.getString("amount");
		/**
		 * 支付提交的metadata参数原样返回。
		 */
		String metadata = jasonObject.getString("metadata");
		/**
		 * VPY++平台订单号
		 */
		String transaction_no = jasonObject.getString("transaction_no");
		/**
		 * 支付订单状态（是否支付成功）
         * 0处理中，或状态未知
         * 1 成功
         * 2 失败
		 */
		String succeeded = jasonObject.getString("succeeded");
		/**
		 * 错误代码，详细参考API 文档 3.3错误 failure_code 参数说明。
		 */
		String failure_code = jasonObject.getString("failure_code");
		/**
		 * 错误信息描述。
		 */
		String failure_msg = jasonObject.getString("failure_msg");
		
		/**
		 * 对查询结果进行加密校验
		 */
		keyValues = new KeyValues();
		keyValues.add(new KeyValue("app_id", app_id));
		keyValues.add(new KeyValue("order_no", order_no));
		keyValues.add(new KeyValue("amount", amount));
		keyValues.add(new KeyValue("metadata", metadata));
		keyValues.add(new KeyValue("transaction_no", transaction_no));
		keyValues.add(new KeyValue("succeeded", succeeded));
		keyValues.add(new KeyValue("failure_code", failure_code));
		keyValues.add(new KeyValue("failure_msg", failure_msg));
		
		/**
		 * MD5加密，加密值是您的商户KEY。需要修改成您分配的商户KEY
		 */
		String _sign = keyValues.sign("*********************");

		if (!_sign.equals(sign)) {
			System.out.println("校验失败");
			return;
		}else{
			System.out.println("校验成功");
			System.out.println("订单[transaction_no]"+transaction_no+"的状态[succeeded]"+succeeded);
		}

	}

}
