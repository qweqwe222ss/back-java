package util;

public enum HttpMethodType {
    GET,POST,FILE
}
