
import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;

import util.HttpHelper;
import util.HttpMethodType;
import util.KeyValue;
import util.KeyValues;

/**
 * 
 * 支付。 @see VPAY++_API.doc 2.1支持
 *
 */
public class RechargeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RechargeServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// do nothing
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		KeyValues keyValues = new KeyValues();
		/**
		 * 您的商户号。需要修改成您分配的商户号
		 */
		keyValues.add(new KeyValue("app_id", "*********************"));
		/**
		 * 支付渠道 
		 * alipay_wap=支付宝手机网页支付 
		 * alipay_qr=支付宝扫码支付 
		 * alipay_pc=支付宝电脑网页支付
		 * wx_wap=微信手机网站支付 
		 * wx_qr=微信扫码支付 
		 * upacp_pc=银联网关支付，即银联电脑网页支付
		 * upacp_wap=银联手机网页支付
		 */
		/*
		 * 这里使用 银联手机网页支付
		 */
		keyValues.add(new KeyValue("channel", "upacp_wap"));
		
		/**
		 * 商户订单号，商户端产生，最长32位，不可重复
		 */
		keyValues.add(new KeyValue("order_no", "*********************"));
		/**
		 * 客户端IP，请根据客户端提交请求进行修改。支付宝微信有风控，请填写真实 IP 地址。
		 */
		keyValues.add(new KeyValue("client_ip", "127.0.0.1"));
		/**
		 * 充值金额，单位是分。
		 */
		keyValues.add(new KeyValue("amount", "100"));
		/**
		 * 商品标题。根据业务情况进行修改
		 */
		keyValues.add(new KeyValue("subject", "recharge"));
		/**
		 * 商品描述信息。根据业务情况进行修改
		 */
		keyValues.add(new KeyValue("body", "recharge"));
		/**
		 * 支付结果异步通知url
		 * 客户在银行端完成支付后，成功或失败通知到CallbackServlet地址
		 */
		keyValues.add(new KeyValue("notify_url", "*********************"));
		/**
		 * 支付操作完成后界面返回url
		 */
		keyValues.add(new KeyValue("return_url", "*********************"));
		/**
		 * 特定渠道发起交易时需要的额外参数。如果开户没有特别说明，请置空。
		 */
		keyValues.add(new KeyValue("extra", ""));
		
		/**
		 * MD5加密，加密值是您的商户KEY。需要修改成您分配的商户KEY
		 */
		String sign = keyValues.sign("*********************");
		Map<String, Object> param = keyValues.getMap();
		param.put("sign", sign);
		/**
		 * 支付API地址
		 */
		String api_url = "http://api.vpayxx.com/v1/recharge.action";
		
		/**
		 * 调用VPY++支付接口，接口返回json格式的字符串
		 */
		String jsonResult = HttpHelper.getJSONFromHttp(api_url, param, HttpMethodType.POST);

		JSONObject jasonObject = JSONObject.parseObject(jsonResult);

		String code = jasonObject.getString("code");
		if ("200".equals(code)) {
			/*
			 * 支付成功，转下一步处理
			 */
			/**
			 * VPY++平台订单号
			 */
			String transaction_no = jasonObject.getJSONObject("data").getString("transaction_no");
			/**
			 * 商户订单号
			 */
			String order_no = jasonObject.getJSONObject("data").getString("order_no");
			/**
			 * url值类型
			 * 1、url=跳转地址
			 * 2、html=表单html
			 * 3、imgurl=扫码图片地址
			 * 4、imgbase64=扫码图片base6编码
			 * 
			 * 
			 * 手机和PC支付需要支持url和html，根据上游支付渠道不同，会轮询返回不同的结果。
			 * 二维码支付，需支持imgurl和imgbase64
			 */
			String url_type = jasonObject.getJSONObject("data").getString("url_type");
			/**
			 * url值
			 * 如url_type=html,form表格id值=vpay_recharge_form。可以使用js对vpay_recharge_form表单进行submit提交。
			 */
			String url = jasonObject.getJSONObject("data").getString("url");
			
			
			
			
			
		} else {
			/*
			 * 返回code非200，支付失败
			 */
			System.out.println("错误代码[code]" + code);
			String msssage = jasonObject.getString("msssage");
			System.out.println("错误消息[msssage]" + msssage);
		}
	}

}
