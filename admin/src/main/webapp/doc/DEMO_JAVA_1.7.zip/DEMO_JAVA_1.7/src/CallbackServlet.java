
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.KeyValue;
import util.KeyValues;

/**
 * 支付异步通知。@see VPAY++_API.doc 2.2支付异步通知
 */
public class CallbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Set<String> filter = new HashSet<String>();

	public CallbackServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// do nothing
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		/**
		 * 您的商户号。
		 */
		String app_id = request.getParameter("app_id");
		/**
		 * MD5报文加密串
		 */
		String sign = request.getParameter("sign");
		/**
		 * 充值金额，单位是分。
		 */
		String amount = request.getParameter("amount");
		/**
		 * 支付提交的metadata参数原样返回。
		 */
		String metadata = request.getParameter("metadata");
		/**
		 * VPY++平台订单号
		 */
		String transaction_no = request.getParameter("transaction_no");
		/**
		 * 商户订单号
		 */
		String order_no = request.getParameter("order_no");
		/**
		 * 支付订单状态（是否支付成功）
         * 0处理中，或状态未知
         * 1 成功
         * 2 失败
		 */
		String succeeded = request.getParameter("succeeded");
		/**
		 * 错误代码，详细参考API 文档 3.3错误 failure_code 参数说明。
		 */
		String failure_code = request.getParameter("failure_code");
		/**
		 * 错误信息描述。
		 */
		String failure_msg = request.getParameter("failure_msg");

		try {
			/**
			 * 同步锁+内存锁，防止半发导致的重复入账。
			 */
			synchronized (order_no) {

				if (!filter.add(order_no)) {
					System.out.println("订单编号：" + order_no + " 重复通知");
					/**
					 * 返回处理错误
					 */
					out.println("ERROR");
				}
				System.out.println("订单编号：" + order_no + " 已加入过滤器");

				KeyValues keyValues = new KeyValues();
				keyValues.add(new KeyValue("app_id", app_id));
				keyValues.add(new KeyValue("order_no", order_no));
				keyValues.add(new KeyValue("amount", amount));
				keyValues.add(new KeyValue("metadata", metadata));
				keyValues.add(new KeyValue("transaction_no", transaction_no));
				keyValues.add(new KeyValue("succeeded", succeeded));
				keyValues.add(new KeyValue("failure_code", failure_code));
				keyValues.add(new KeyValue("failure_msg", failure_msg));
				
				 /**
				 * MD5加密，加密值是您的商户KEY。需要修改成您分配的商户KEY
				 */
				String _sign = keyValues.sign("*********************");

				if (!_sign.equals(sign)) {
					System.out.println("校验失败");
					out.println("ERROR");
				}

				/**
				 * 校验成功，业务处理，并返回"SUCCESS"
				 */
				out.println("SUCCESS");
				/**
				 * 业务处理完，请休眠线程200毫秒，保证事务提交。事务需要在锁释放前commit
				 */
				Thread.sleep(200);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
			/**
			 * 释放内存锁，否则如果没有处理成功，下个报文无法处理。
			 */
			filter.remove(order_no);
			
		}

	}

}
